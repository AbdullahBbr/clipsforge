"""Animated captions as ASS subtitles, burned in by ffmpeg.

Three templates. Words are grouped 2-4 at a time; inside a group the
word being spoken is highlighted with karaoke timing and a small pop.
libass centres each group, so no per-word pixel layout is needed.
"""
import re

TEMPLATES = {
    "bold": {"label": "Bold", "font": "Poppins ExtraBold", "size": 96,
             "base": "FFFFFF", "active": "00F0FF", "outline": 6, "upper": True, "per": 3},
    "karaoke": {"label": "Karaoke", "font": "Anton", "size": 108,
                "base": "FFFFFF", "active": "3C3CFF", "outline": 6, "upper": True, "per": 2},
    "minimal": {"label": "Minimal", "font": "Poppins ExtraBold", "size": 72,
                "base": "FFFFFF", "active": "6BD7FF", "outline": 4, "upper": False, "per": 4},
}
W, H = 1080, 1920


def _ts(t):
    t = max(0.0, float(t))
    h, m = int(t // 3600), int(t % 3600 // 60)
    return f"{h}:{m:02d}:{t % 60:05.2f}"


def _clean(text):
    text = re.sub(r"[{}\\]", "", str(text))
    return re.sub(r"[\x00-\x1f\x7f]+", " ", text).strip()


def _groups(words, per):
    out, cur = [], []
    for w in words:
        if cur and (len(cur) >= per or w["s"] - cur[-1]["e"] > 0.45
                    or cur[-1]["w"][-1:] in ".?!"):
            out.append(cur)
            cur = []
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def build_ass(words, start, end, hook="", style_name="bold"):
    st = TEMPLATES.get(style_name, TEMPLATES["bold"])
    head = (
        "[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\n"
        "WrapStyle: 2\nScaledBorderAndShadow: yes\n\n[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, "
        "OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, "
        "ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, "
        "Alignment, MarginL, MarginR, MarginV, Encoding\n"
        f"Style: Cap,{st['font']},{st['size']},&H00{st['base']},&H00{st['active']},"
        f"&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,{st['outline']},0,2,0,0,0,1\n"
        f"Style: Hook,{st['font']},88,&H0014100E,&H0014100E,&H00000000,&H00000000,"
        "0,0,0,0,100,100,0,0,1,0,0,8,0,0,0,1\n\n[Events]\n"
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    )
    events = []
    hook = _clean(hook)
    if hook:
        dur = end - start
        events.append(f"Dialogue: 0,{_ts(0)},{_ts(min(dur, 3.0))},Hook,,0,0,0,,"
                      f"{{\\an8\\pos(540,260)\\fad(150,0)}}{hook.upper()}")
    inside = sorted((dict(w, w=_clean(w["w"])) for w in words
                     if w["s"] >= start - 0.05 and w["s"] < end and _clean(w["w"])),
                    key=lambda w: w["s"])
    for i, w in enumerate(inside[:-1]):
        w["e"] = max(w["s"], min(w["e"], inside[i + 1]["s"]))
    for g in _groups(inside, st["per"]):
        g_start = max(0.0, g[0]["s"] - start)
        g_end = min(g[-1]["e"] + 0.25, end) - start
        if g_end - g_start < 0.05:
            continue
        parts = []
        for w in g:
            text = re.sub(r"[.,;:]+$", "", w["w"])
            text = text.upper() if st["upper"] else text
            dur_cs = max(1, int((w["e"] - w["s"]) * 100))
            parts.append("{\\kf%d}%s" % (dur_cs, text))
        line = " ".join(parts)
        events.append(f"Dialogue: 0,{_ts(g_start)},{_ts(g_end)},Cap,,0,0,0,,"
                      f"{{\\an2\\pos(540,1450)}}{line}")
    return head + "\n".join(events) + "\n"
