"""Settings, read from the environment (and a .env file if present)."""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _load_dotenv():
    env = ROOT / ".env"
    if env.is_file():
        for line in env.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip())


_load_dotenv()

DATA_DIR = Path(os.environ.get("CLIPFORGE_DATA") or (ROOT / "data")).expanduser()
DATA_DIR.mkdir(parents=True, exist_ok=True)
PORT = int(os.environ.get("CLIPFORGE_PORT", "8765"))
WHISPER_MODEL = os.environ.get("CLIPFORGE_WHISPER_MODEL", "base").strip() or "base"
FONTS_DIR = Path(__file__).resolve().parent / "fonts"
YT_COOKIES = os.environ.get("CLIPFORGE_YT_COOKIES", "").strip()
YOUTUBE_CLIENT_SECRETS = os.environ.get("CLIPFORGE_YOUTUBE_CLIENT_SECRETS", "").strip()

# A single job's source video is never fetched longer than this.
MAX_VIDEO_HOURS = 12
# Clips are 1080x1920, 30 fps, like a vertical short.
OUT_W, OUT_H, OUT_FPS = 1080, 1920, 30
# Thumbnails are 1280x720 (YouTube's standard).
THUMB_W, THUMB_H = 1280, 720

ALLOWED_SITES = (
    "youtube.com", "youtu.be", "youtube-nocookie.com",
    "twitch.tv", "clips.twitch.tv", "vimeo.com",
)
