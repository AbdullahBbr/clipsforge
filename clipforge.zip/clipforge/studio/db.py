"""SQLite storage for jobs, clips and scheduled posts. Plain sqlite3, no ORM."""
import json
import sqlite3
import threading
from pathlib import Path

from . import config

_lock = threading.Lock()
DB_PATH = config.DATA_DIR / "clipforge.db"


def _connect():
    conn = sqlite3.connect(str(DB_PATH), timeout=30)
    conn.row_factory = sqlite3.Row
    return conn


def init():
    with _lock, _connect() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS jobs (
            id TEXT PRIMARY KEY, title TEXT, source TEXT, kind TEXT,
            status TEXT, progress REAL, error TEXT, created_at REAL,
            duration REAL, max_clips INTEGER, clip_length REAL, lang TEXT
        );
        CREATE TABLE IF NOT EXISTS clips (
            id TEXT PRIMARY KEY, job_id TEXT, title TEXT, hook TEXT,
            start REAL, end REAL, score REAL, style TEXT, layout TEXT,
            file TEXT, cover TEXT, transcript_json TEXT, created_at REAL,
            FOREIGN KEY(job_id) REFERENCES jobs(id)
        );
        CREATE TABLE IF NOT EXISTS schedules (
            id TEXT PRIMARY KEY, clip_id TEXT, platform TEXT,
            publish_at TEXT, title TEXT, description TEXT, hashtags TEXT,
            status TEXT, note TEXT, created_at REAL,
            FOREIGN KEY(clip_id) REFERENCES clips(id)
        );
        """)
    return DB_PATH


def _row(r):
    return dict(r) if r is not None else None


def create_job(job):
    with _lock, _connect() as conn:
        conn.execute(
            "INSERT INTO jobs VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (job["id"], job.get("title", ""), job.get("source", ""), job.get("kind", ""),
             job.get("status", "queued"), 0.0, "", job["created_at"],
             job.get("duration", 0), job.get("max_clips", 3),
             job.get("clip_length", 45), job.get("lang", "en")))


def update_job(job_id, **fields):
    if not fields:
        return
    keys = ", ".join(f"{k}=?" for k in fields)
    with _lock, _connect() as conn:
        conn.execute(f"UPDATE jobs SET {keys} WHERE id=?", (*fields.values(), job_id))


def get_job(job_id):
    with _connect() as conn:
        return _row(conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone())


def list_jobs(limit=50):
    with _connect() as conn:
        return [_row(r) for r in conn.execute(
            "SELECT * FROM jobs ORDER BY created_at DESC LIMIT ?", (limit,))]


def create_clip(clip):
    with _lock, _connect() as conn:
        conn.execute(
            "INSERT INTO clips VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (clip["id"], clip["job_id"], clip.get("title", ""), clip.get("hook", ""),
             clip["start"], clip["end"], clip.get("score", 0), clip.get("style", "bold"),
             clip.get("layout", "crop"), clip.get("file", ""), clip.get("cover", ""),
             json.dumps(clip.get("words", [])), clip["created_at"]))


def update_clip(clip_id, **fields):
    if not fields:
        return
    if "words" in fields:
        fields = dict(fields)
        fields["transcript_json"] = json.dumps(fields.pop("words"))
    keys = ", ".join(f"{k}=?" for k in fields)
    with _lock, _connect() as conn:
        conn.execute(f"UPDATE clips SET {keys} WHERE id=?", (*fields.values(), clip_id))


def get_clip(clip_id):
    with _connect() as conn:
        row = _row(conn.execute("SELECT * FROM clips WHERE id=?", (clip_id,)).fetchone())
    if row:
        row["words"] = json.loads(row.pop("transcript_json") or "[]")
    return row


def clips_for_job(job_id):
    with _connect() as conn:
        rows = [_row(r) for r in conn.execute(
            "SELECT * FROM clips WHERE job_id=? ORDER BY score DESC", (job_id,))]
    for r in rows:
        r["words"] = json.loads(r.pop("transcript_json") or "[]")
    return rows


def list_clips(limit=100):
    with _connect() as conn:
        rows = [_row(r) for r in conn.execute(
            "SELECT * FROM clips ORDER BY created_at DESC LIMIT ?", (limit,))]
    for r in rows:
        r["words"] = json.loads(r.pop("transcript_json") or "[]")
    return rows


def create_schedule(entry):
    with _lock, _connect() as conn:
        conn.execute(
            "INSERT INTO schedules VALUES (?,?,?,?,?,?,?,?,?,?)",
            (entry["id"], entry["clip_id"], entry["platform"], entry["publish_at"],
             entry.get("title", ""), entry.get("description", ""),
             entry.get("hashtags", ""), entry.get("status", "queued"),
             entry.get("note", ""), entry["created_at"]))


def list_schedules():
    with _connect() as conn:
        return [_row(r) for r in conn.execute(
            "SELECT * FROM schedules ORDER BY publish_at, created_at")]


def get_schedule(schedule_id):
    with _connect() as conn:
        return _row(conn.execute("SELECT * FROM schedules WHERE id=?", (schedule_id,)).fetchone())


def update_schedule(schedule_id, **fields):
    if not fields:
        return
    keys = ", ".join(f"{k}=?" for k in fields)
    with _lock, _connect() as conn:
        conn.execute(f"UPDATE schedules SET {keys} WHERE id=?", (*fields.values(), schedule_id))
