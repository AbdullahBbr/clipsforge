"""Social scheduler: a queue in SQLite. A scheduled post is a publish
package (clip + title + description + hashtags + time). Nothing is
actually posted by this module on its own.

YouTube upload is an optional, credentials-gated step: it only runs
when the owner has put OAuth client secrets in place (see README).
Without them, a due post stays 'queued' with a plain note saying why.
ClipForge never pretends a post went out when it did not.
"""
import time
import uuid

from . import config, db

PLATFORMS = ("youtube", "tiktok", "instagram", "x", "facebook", "linkedin")


def queue_post(clip_id, platform, publish_at, title="", description="", hashtags=""):
    if platform not in PLATFORMS:
        raise ValueError(f"Platform has to be one of: {', '.join(PLATFORMS)}.")
    if not db.get_clip(clip_id):
        raise ValueError("That clip doesn't exist any more.")
    entry = {"id": uuid.uuid4().hex[:12], "clip_id": clip_id, "platform": platform,
             "publish_at": publish_at, "title": title or "", "description": description or "",
             "hashtags": hashtags or "", "status": "queued", "note": "", "created_at": time.time()}
    db.create_schedule(entry)
    return entry


def due_posts(now=None):
    now = now or time.strftime("%Y-%m-%dT%H:%M")
    return [s for s in db.list_schedules()
            if s["status"] == "queued" and s["publish_at"] <= now]


def try_publish(schedule_id):
    """Attempt a due post. YouTube only, and only with credentials.
    Returns the updated schedule row. Never marks a post 'posted' unless
    an upload actually succeeded."""
    entry = db.get_schedule(schedule_id)
    if not entry:
        raise ValueError("That scheduled post doesn't exist any more.")
    if entry["platform"] != "youtube":
        db.update_schedule(schedule_id, status="queued",
                           note=(f"{entry['platform'].title()} posting needs that account "
                                 "connected first. This post is still queued — nothing was posted."))
        return db.get_schedule(schedule_id)
    if not config.YOUTUBE_CLIENT_SECRETS:
        db.update_schedule(schedule_id, status="queued",
                           note=("YouTube upload needs your OAuth credentials. Add them as "
                                 "CLIPFORGE_YOUTUBE_CLIENT_SECRETS (see README) and try again. "
                                 "Nothing was posted."))
        return db.get_schedule(schedule_id)
    # Credentials are present but no upload client is bundled in v1:
    # saying "posted" here would be a lie, so the post stays queued.
    db.update_schedule(schedule_id, status="queued",
                       note=("YouTube credentials are set, but automatic upload isn't "
                             "wired up in this version yet. Download the clip and upload "
                             "it in YouTube Studio, or ask for the upload step to be added."))
    return db.get_schedule(schedule_id)
