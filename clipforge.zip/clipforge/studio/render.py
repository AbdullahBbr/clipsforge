"""Render a clip: centre-crop to 1080x1920, burn animated captions in,
normalise the audio. Work is done in a short temp folder (ffmpeg's
caption step cannot open very long paths on Windows) and moved into place.
"""
import shutil
import subprocess
import tempfile
from pathlib import Path

from . import captions, config
from .media import NO_WINDOW, run

W, H = config.OUT_W, config.OUT_H


def render_clip(src, out_dir, name, clip, words):
    """Write <name>.mp4 + <name>.jpg into out_dir. Returns file names."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    start, end = float(clip["start"]), float(clip["end"])
    style = clip.get("style", "bold")
    ass = captions.build_ass(words, start, end, clip.get("hook", ""), style)
    work = Path(tempfile.mkdtemp(prefix="cf"))
    try:
        return _render_in(work, src, out_dir, name, start, end, ass)
    finally:
        shutil.rmtree(work, ignore_errors=True)


def _render_in(work, src, out_dir, name, start, end, ass):
    (work / f"{name}.ass").write_text(ass, encoding="utf-8")
    (work / "f").mkdir()
    for f in config.FONTS_DIR.glob("*.ttf"):
        shutil.copyfile(f, work / "f" / f.name)
    fc = (f"[0:v]fps={config.OUT_FPS},scale={W}:{H}:force_original_aspect_ratio=increase,"
          f"crop={W}:{H},setsar=1[v0];[v0]ass={name}.ass:fontsdir=f[v]")
    cmd = ["ffmpeg", "-y", "-v", "error", "-ss", f"{start:.2f}", "-t", f"{end - start:.2f}",
           "-i", str(src), "-filter_complex", fc, "-map", "[v]", "-map", "0:a:0",
           "-af", "loudnorm=I=-14:TP=-1.5:LRA=11", "-c:a", "aac", "-b:a", "160k",
           "-ar", "48000", "-c:v", "libx264", "-crf", "21", "-preset", "veryfast",
           "-pix_fmt", "yuv420p", "-movflags", "+faststart", f"{name}.mp4"]
    p = subprocess.run(cmd, cwd=work, capture_output=True, text=True,
                       encoding="utf-8", errors="replace",
                       creationflags=NO_WINDOW, timeout=600)
    if p.returncode != 0:
        raise RuntimeError(f"Render failed: {p.stderr[-1200:]}")
    cover_t = min(1.2, (end - start) / 2)
    run(["ffmpeg", "-y", "-v", "error", "-ss", f"{cover_t:.2f}", "-i", f"{name}.mp4",
         "-frames:v", "1", "-q:v", "3", f"{name}.jpg"], cwd=work)
    for ext in ("mp4", "jpg", "ass"):
        shutil.move(str(work / f"{name}.{ext}"), str(out_dir / f"{name}.{ext}"))
    return {"file": f"{name}.mp4", "cover": f"{name}.jpg", "layout": "crop"}


def reframe_clip(src, out_path, ratio="9:16"):
    """Re-render a clip at a different aspect ratio (9:16, 1:1 or 16:9)."""
    ratios = {"9:16": (1080, 1920), "1:1": (1080, 1080), "16:9": (1920, 1080)}
    w, h = ratios.get(ratio, (1080, 1920))
    cmd = ["ffmpeg", "-y", "-v", "error", "-i", str(src),
           "-vf", f"scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},setsar=1",
           "-c:a", "copy", "-c:v", "libx264", "-crf", "21", "-preset", "veryfast",
           "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(out_path)]
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                       errors="replace", creationflags=NO_WINDOW, timeout=600)
    if p.returncode != 0:
        raise RuntimeError(f"Reframe failed: {p.stderr[-1200:]}")
    return out_path
