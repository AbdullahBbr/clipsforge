"""Thumbnails: grab a frame, overlay a title, save 1280x720."""
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from . import config
from .media import run

W, H = config.THUMB_W, config.THUMB_H


def _font(size):
    for name in ("Poppins-ExtraBold.ttf", "Anton-Regular.ttf"):
        p = config.FONTS_DIR / name
        if p.is_file():
            try:
                return ImageFont.truetype(str(p), size)
            except Exception:
                pass
    return ImageFont.load_default()


def _wrap(draw, text, font, max_w):
    words, lines, cur = text.split(), [], ""
    for w in words:
        trial = f"{cur} {w}".strip()
        if draw.textlength(trial, font=font) <= max_w or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def make_thumbnail(video_path, out_path, title="", at=None):
    """Frame from the middle of the video (or `at` seconds), title on top."""
    video_path, out_path = Path(video_path), Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    from .media import probe
    dur = probe(video_path)["duration"]
    t = min(max(0.5, at if at is not None else dur / 2), max(0.5, dur - 0.2))
    tmp = out_path.with_suffix(".frame.jpg")
    run(["ffmpeg", "-y", "-v", "error", "-ss", f"{t:.2f}", "-i", str(video_path),
         "-frames:v", "1", "-vf", f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H}",
         "-q:v", "3", str(tmp)])
    img = Image.open(tmp).convert("RGB")
    draw = ImageDraw.Draw(img)
    # darken the bottom half so the title reads on any frame
    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    od = ImageDraw.Draw(overlay)
    od.rectangle([0, H - 260, W, H], fill=(0, 0, 0, 140))
    img = Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB")
    draw = ImageDraw.Draw(img)
    title = (title or "").strip() or "Clip"
    font = _font(72)
    lines = _wrap(draw, title.upper(), font, W - 120)[:3]
    y = H - 240
    for line in lines:
        draw.text((60, y), line, font=font, fill=(255, 255, 255),
                  stroke_width=3, stroke_fill=(0, 0, 0))
        y += 84
    img.save(out_path, "JPEG", quality=88)
    tmp.unlink(missing_ok=True)
    return out_path
