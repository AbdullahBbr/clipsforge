"""ClipForge MCP server (stdio). Exposes the same core features as the
web app, mirroring OpusClip's most-used MCP tools in our own names.

Run:  python -m studio.mcp_server
Tools: clip_video, list_clips, get_transcript, caption_clip,
reframe_clip, make_thumbnail, dub_clip, schedule_post.
"""
import json
import time
import uuid
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from . import config, db, dub, editor, jobs, media, render, schedule, thumbs

db.init()
mcp = FastMCP("clipforge")


def _clip_dict(c):
    return {"id": c["id"], "job_id": c["job_id"], "title": c["title"], "hook": c["hook"],
            "start": c["start"], "end": c["end"], "score": c["score"],
            "style": c["style"], "file": c["file"],
            "video": str(jobs.job_dir(c["job_id"]) / "clips" / c["file"])}


@mcp.tool()
def clip_video(url: str, max_clips: int = 3, clip_length: float = 45,
               lang: str = "en") -> str:
    """Make clips from a YouTube/Twitch/direct video link. Returns the job
    id; use list_clips to see the finished clips."""
    url = url.strip()
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    if not media.site_allowed(url):
        return json.dumps({"error": "That link isn't from a supported video site. Use a YouTube or Twitch link."})
    try:
        meta = media.info(url)
    except Exception as e:
        return json.dumps({"error": str(e)[:400]})
    job = jobs.create_job(url, "url", max_clips=max_clips, clip_length=clip_length,
                          lang=lang, title=meta.get("title", ""))
    return json.dumps({"job_id": job["id"], "title": job["title"],
                       "status": "queued", "note": "Clips are rendering in the background. Call list_clips with this job_id to check."})


@mcp.tool()
def list_clips(job_id: str = "") -> str:
    """List clips (optionally for one job), with their scores and files."""
    clips = db.clips_for_job(job_id) if job_id else db.list_clips()
    return json.dumps([_clip_dict(c) for c in clips])


@mcp.tool()
def get_transcript(clip_id: str) -> str:
    """The clip's transcript, word by word with timings."""
    clip = db.get_clip(clip_id)
    if not clip:
        return json.dumps({"error": "That clip doesn't exist."})
    return json.dumps({"clip_id": clip_id, "title": clip["title"], "words": clip["words"]})


@mcp.tool()
def caption_clip(clip_id: str, caption_style: str = "bold",
                 caption_text: str = "") -> str:
    """Re-render a clip with a different caption style (bold, karaoke,
    minimal) or with replacement caption text."""
    try:
        clip = editor.edit_clip(clip_id, caption_style=caption_style,
                                caption_text=caption_text or None)
    except Exception as e:
        return json.dumps({"error": str(e)[:400]})
    return json.dumps(_clip_dict(clip))


@mcp.tool()
def reframe_clip(clip_id: str, ratio: str = "9:16") -> str:
    """Re-render a clip at 9:16, 1:1 or 16:9."""
    clip = db.get_clip(clip_id)
    if not clip:
        return json.dumps({"error": "That clip doesn't exist."})
    src = jobs.job_dir(clip["job_id"]) / "clips" / clip["file"]
    out = jobs.job_dir(clip["job_id"]) / "clips" / f"clip-{clip_id}-{ratio.replace(':', 'x')}.mp4"
    try:
        render.reframe_clip(src, out, ratio)
    except Exception as e:
        return json.dumps({"error": str(e)[:400]})
    return json.dumps({"clip_id": clip_id, "ratio": ratio, "file": str(out)})


@mcp.tool()
def make_thumbnail(clip_id: str, title: str = "") -> str:
    """Make a 1280x720 thumbnail for a clip."""
    clip = db.get_clip(clip_id)
    if not clip:
        return json.dumps({"error": "That clip doesn't exist."})
    src = jobs.job_dir(clip["job_id"]) / "clips" / clip["file"]
    out = jobs.job_dir(clip["job_id"]) / "clips" / f"clip-{clip_id}-thumb.jpg"
    try:
        thumbs.make_thumbnail(src, out, title or clip["title"])
    except Exception as e:
        return json.dumps({"error": str(e)[:400]})
    return json.dumps({"clip_id": clip_id, "thumbnail": str(out), "size": "1280x720"})


@mcp.tool()
def dub_clip(clip_id: str, target_lang: str = "es") -> str:
    """Dub a clip into another language (e.g. es, fr, de). Falls back to
    translated captions over the original audio when the voice service
    can't be reached."""
    clip = db.get_clip(clip_id)
    if not clip:
        return json.dumps({"error": "That clip doesn't exist."})
    clip_path = jobs.job_dir(clip["job_id"]) / "clips" / clip["file"]
    out = jobs.job_dir(clip["job_id"]) / "clips" / f"clip-{clip_id}-dub-{target_lang[:2]}.mp4"
    try:
        return json.dumps(dub.dub_clip(clip_path, clip["words"], target_lang, out))
    except Exception:
        try:
            return json.dumps(dub.translated_captions_fallback(
                clip_path, clip["words"], target_lang, out))
        except Exception as e:
            return json.dumps({"error": str(e)[:400]})


@mcp.tool()
def schedule_post(clip_id: str, platform: str, publish_at: str,
                  title: str = "", description: str = "", hashtags: str = "") -> str:
    """Queue a clip to be posted later. This only queues the post — it
    does not post it. Posting needs the platform account connected."""
    try:
        entry = schedule.queue_post(clip_id, platform, publish_at, title, description, hashtags)
    except Exception as e:
        return json.dumps({"error": str(e)[:400]})
    return json.dumps(entry)


def main():
    mcp.run()


if __name__ == "__main__":
    main()
