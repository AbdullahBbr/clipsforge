"""Clip selection: score every candidate window of the transcript.

Explainable, local scoring — not a trained virality model, and the plan
says so honestly. A good clip has: dense speech, a hook in the first
seconds (a question, "how", "why", "secret", "never", "stop", ...),
energy (loudness above the video's median), and variety. Windows that
overlap a better window are dropped.
"""
import math
import re

HOOK_WORDS = {"how", "why", "what", "secret", "never", "always", "stop", "amazing",
              "incredible", "best", "worst", "mistake", "truth", "free", "new", "first",
              "nobody", "everyone", "actually", "really", "watch", "look", "wait"}
HOOK_RE = re.compile(r"\b(how|why|what if|did you know|the secret|you won't|never|stop)\b", re.I)


def _words_in(words, start, end):
    return [w for w in words if start <= w["s"] < end]


def _sentence_starts(words):
    """Times where a sentence seems to start — good clip boundaries."""
    starts = {0.0}
    for i, w in enumerate(words):
        if w["w"] and w["w"][-1] in ".?!":
            if i + 1 < len(words):
                starts.add(words[i + 1]["s"])
    return sorted(starts)


def score_windows(words, duration, clip_length=45, max_clips=3, loudness=None):
    """Return [{start, end, score, hook, text}] sorted by score, non-overlapping."""
    if not words or duration <= 0:
        return []
    length = max(15.0, min(float(clip_length), 90.0))
    step = 5.0
    # median loudness, for the energy term
    med_db = -40.0
    if loudness:
        vals = sorted(loudness)
        med_db = vals[len(vals) // 2] if vals else -40.0

    starts = _sentence_starts(words)
    # candidate starts: sentence starts + a regular grid, so speech without
    # punctuation still gets candidates
    cand = sorted(set(starts) | {round(t, 1) for t in _frange(0, max(0, duration - length), step)})
    scored = []
    for s in cand:
        e = min(s + length, duration)
        if e - s < 15:
            continue
        ws = _words_in(words, s, e)
        if len(ws) < 12:  # too little speech to be a clip
            continue
        text = " ".join(w["w"] for w in ws)
        density = len(ws) / (e - s)  # words per second
        density_score = min(1.0, density / 2.5)
        # hook: strong words in the first 6 seconds
        first = _words_in(words, s, s + 6)
        first_text = " ".join(w["w"] for w in first).lower()
        hook_hits = sum(1 for w in HOOK_WORDS if w in first_text)
        hook_score = min(1.0, (hook_hits * 0.25) + (0.3 if HOOK_RE.search(first_text) else 0)
                         + (0.2 if "?" in first_text else 0))
        # energy: mean loudness in the window vs the video median
        energy = 0.5
        if loudness:
            seg = loudness[int(s): int(e)] or [med_db]
            energy = max(0.0, min(1.0, 0.5 + (sum(seg) / len(seg) - med_db) / 20.0))
        # variety: distinct words (a repeated chorus scores lower)
        uniq = len({w["w"].lower().strip(".,!?") for w in ws})
        variety = min(1.0, uniq / max(1, len(ws)) * 1.4)
        # prefer the first half slightly — hooks land early in a video
        position = 1.0 - 0.15 * (s / max(1, duration))
        score = round(100 * (0.35 * density_score + 0.25 * hook_score + 0.2 * energy
                             + 0.1 * variety + 0.1 * position), 1)
        hook = " ".join(w["w"] for w in first[:8])
        scored.append({"start": round(s, 2), "end": round(e, 2), "score": score,
                       "hook": hook, "text": text[:400]})
    scored.sort(key=lambda c: -c["score"])
    picked = []
    for c in scored:
        if all(c["end"] <= p["start"] + 2 or c["start"] >= p["end"] - 2 for p in picked):
            picked.append(c)
        if len(picked) >= max_clips:
            break
    # if nothing scored (e.g. music with few words), fall back to the
    # loudest stretch of the requested length
    if not picked and duration >= 15:
        best_s, best_e = 0.0, min(length, duration)
        if loudness:
            best = max(range(0, max(1, int(duration - length))),
                       key=lambda i: sum(loudness[i:i + int(length)]) if i + int(length) <= len(loudness) else -1e9,
                       default=0)
            best_s, best_e = float(best), float(best) + length
        ws = _words_in(words, best_s, best_e)
        picked.append({"start": round(best_s, 2), "end": round(min(best_e, duration), 2),
                       "score": 50.0, "hook": " ".join(w["w"] for w in ws[:8]),
                       "text": " ".join(w["w"] for w in ws)[:400]})
    return picked


def _frange(a, b, step):
    t = a
    while t <= b:
        yield t
        t += step


def title_from_hook(hook, fallback="Clip"):
    text = (hook or "").strip().strip(".,!?")
    if not text:
        return fallback
    words = text.split()
    return " ".join(words[:8]).capitalize() if words else fallback
