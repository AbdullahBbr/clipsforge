"""Getting video in: YouTube / Twitch / direct link download, probing, audio.

Patterns follow PeakCut's proven approach (the user's own earlier code):
unpinned first yt-dlp try, Android player fallback when YouTube refuses
the web player, a short pause after a bot-block, optional cookies.txt,
ranged audio fetch, and plain-language errors instead of yt-dlp's raw text.
"""
import contextlib
import json
import os
import re
import subprocess
import time
from pathlib import Path
from urllib.parse import urlparse

from . import config

NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
       "Chrome/126.0.0.0 Safari/537.36")
_BOT_CHECK = re.compile(r"not a bot|confirm you.?re not|sign in to confirm(?! your age)|po.?token|nsig", re.I)
_CLIENT_FAILURE = re.compile(r"not a bot|confirm you.?re not|sign in to confirm|requested format is not available|"
                             r"page needs to be reloaded|po.?token|nsig|403|forbidden|unable to extract", re.I)
_YT_FALLBACK_CLIENTS = tuple(
    s.strip().lower() for s in os.environ.get("CLIPFORGE_YT_CLIENTS", "android").split(",")
    if s.strip() and s.strip().lower() != "web") or ()
YT_PAUSE = 600
_yt_refused_until = 0.0
YT_BLOCKED = ("YouTube isn't letting ClipForge download videos right now. Upload the video file "
              "instead, or use a Twitch link. YouTube links will be tried again in a few minutes. "
              "If this keeps happening, put a cookies.txt from your browser in ClipForge's data "
              "folder (see README, 'YouTube keeps refusing').")


class YouTubeBlocked(RuntimeError):
    pass


def host_of(url):
    return (urlparse((url or "").strip()).hostname or "").lower()


def is_youtube(url):
    h = host_of(url)
    return h in ("youtube.com", "youtu.be", "www.youtube-nocookie.com") or h.endswith(
        (".youtube.com", ".youtu.be", ".youtube-nocookie.com"))


def is_twitch(url):
    h = host_of(url)
    return h in ("twitch.tv", "clips.twitch.tv") or h.endswith((".twitch.tv",))


def site_allowed(url):
    try:
        u = urlparse(url.strip())
    except ValueError:
        return False
    h = (u.hostname or "").lower()
    return u.scheme in ("http", "https") and any(
        h == s or h.endswith("." + s) for s in config.ALLOWED_SITES)


def _cookies_file():
    env_path = os.environ.get("CLIPFORGE_YT_COOKIES", "").strip() or config.YT_COOKIES
    if env_path and Path(env_path).is_file():
        return env_path
    cand = config.DATA_DIR / "cookies.txt"
    return str(cand) if cand.is_file() else ""


def _friendly(err):
    text, low = str(err), str(err).lower()
    if "private video" in low:
        return "That video is private, so ClipForge can't open it. Use a public link, or upload the video file instead."
    if "members-only" in low or "members only" in low or "join this channel" in low:
        return "That video is only for channel members, so ClipForge can't open it. Upload the video file instead."
    if "video unavailable" in low or "has been deleted" in low or "has been removed" in low:
        return "That video is unavailable or has been deleted. Check the link and paste it again."
    if "sign in to confirm your age" in low:
        return "YouTube needs a sign-in to show this video (age-restricted). Upload the video file instead."
    if "copyright" in low:
        return "That video can't be downloaded because of a copyright block. Upload the video file instead."
    if "requested format is not available" in low:
        return "YouTube didn't offer a format ClipForge can download for this video. Try again in a bit."
    if "urlopen error" in low or "timed out" in low or "connection" in low:
        return "The video site couldn't be reached just now. Check the connection and try the link again."
    last = [line for line in text.splitlines() if line.strip()]
    tail = re.sub(r"^ERROR:\s*(\[[^\]]+\]\s*)?", "", last[-1] if last else text).strip()
    return f"Couldn't open that video: {tail[:200]}" if tail else "Couldn't open that video. Check the link is public and complete."


def _raise_friendly(err):
    if _BOT_CHECK.search(str(err)):
        raise err
    raise ValueError(_friendly(err)) from None


@contextlib.contextmanager
def _youtube_guard(url):
    global _yt_refused_until
    if is_youtube(url) and time.time() < _yt_refused_until:
        raise YouTubeBlocked(YT_BLOCKED)
    try:
        yield
    except YouTubeBlocked:
        raise
    except Exception as e:
        if is_youtube(url) and _BOT_CHECK.search(str(e)):
            _yt_refused_until = time.time() + YT_PAUSE
            raise YouTubeBlocked(YT_BLOCKED) from None
        raise


def run(cmd, cwd=None, timeout=3600):
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, encoding="utf-8",
                           errors="replace", creationflags=NO_WINDOW, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise RuntimeError(f"{Path(str(cmd[0])).name} took too long and was stopped.")
    if p.returncode != 0:
        raise RuntimeError(f"{Path(str(cmd[0])).name} failed: {p.stderr[-1500:]}")
    return p.stdout


class _Quiet:
    def debug(self, m): pass
    def info(self, m): pass
    def warning(self, m): pass
    def error(self, m): pass


def _ydl(opts, client=None):
    import yt_dlp
    base = {"noplaylist": True, "quiet": True, "no_warnings": True, "logger": _Quiet(),
            "extract_flat": "in_playlist", "playlistend": 1, "socket_timeout": 20,
            "concurrent_fragment_downloads": 4, "retries": 3, "fragment_retries": 3,
            "http_headers": {"User-Agent": _UA, "Accept-Language": "en-US,en;q=0.9"}}
    if client:
        base["extractor_args"] = {"youtube": {"player_client": [client]}}
    cookies = _cookies_file()
    if cookies:
        base["cookiefile"] = cookies
    return yt_dlp.YoutubeDL({**base, **opts})


def _try_clients(url, opts, fn):
    clients = (None, *_YT_FALLBACK_CLIENTS) if is_youtube(url) else (None,)
    last = None
    for client in clients:
        try:
            with _ydl(opts, client) as ydl:
                return fn(ydl)
        except Exception as e:
            last = e
            if client is None or not _CLIENT_FAILURE.search(str(e)):
                raise
    raise last


def _video_format(height):
    return f"bv*[height<={height}][vcodec^=avc1]+ba[ext=m4a]/bv*[height<={height}]+ba/b[height<={height}]/b"


def _biggest(job_dir, stem):
    files = sorted((p for p in Path(job_dir).glob(stem + ".*")
                    if p.suffix not in (".part", ".ytdl")),
                   key=lambda p: p.stat().st_size, reverse=True)
    if not files:
        raise RuntimeError("Download finished but no file was produced.")
    return files[0]


def info(url):
    """Title, channel and length, without downloading anything."""
    with _youtube_guard(url):
        try:
            i = _try_clients(url, {}, lambda ydl: ydl.extract_info(url, download=False))
        except Exception as e:
            _raise_friendly(e)
    return {"title": i.get("title") or "", "uploader": i.get("uploader") or i.get("channel") or "",
            "duration": float(i.get("duration") or 0), "is_live": bool(i.get("is_live")),
            "thumbnail": i.get("thumbnail") or "", "kind": i.get("_type") or "video"}


def youtube_words(url):
    """YouTube's own transcript, word by word, or None. Fast and accurate
    when the video has captions; transcription falls back to Whisper."""
    if not is_youtube(url):
        return None

    def run(ydl):
        i = ydl.extract_info(url, download=False)
        auto = i.get("automatic_captions") or {}
        key = next((k for k in auto if k.endswith("-orig")), None)
        if not key and i.get("language") in auto:
            key = i["language"]
        track = next((f for f in auto.get(key) or [] if f.get("ext") == "json3" and f.get("url")), None) if key else None
        if not track:
            # fall back to any manual caption track in json3
            subs = i.get("subtitles") or {}
            for k in subs:
                track = next((f for f in subs[k] if f.get("ext") == "json3" and f.get("url")), None)
                if track:
                    break
        if not track:
            return None
        raw = ydl.urlopen(track["url"]).read(40_000_000)
        return _caption_words(json.loads(raw))

    with _youtube_guard(url):
        try:
            return _try_clients(url, {}, run)
        except Exception:
            return None  # transcript is a shortcut, never a blocker


def _caption_words(data):
    out = []
    for ev in data.get("events") or []:
        segs = [x for x in ev.get("segs") or [] if (x.get("utf8") or "").strip()]
        if not segs:
            continue
        t0, dur = float(ev.get("tStartMs") or 0), float(ev.get("dDurationMs") or 0)
        timed = len(segs) > 1 or "tOffsetMs" in segs[0]
        for x in segs:
            parts = x["utf8"].split()
            for n, w in enumerate(parts):
                if re.fullmatch(r"[\[(].*[\])]", w) or w in ("[", "]", "__"):
                    continue
                at = t0 + float(x.get("tOffsetMs") or 0) if timed else t0 + dur * n / max(1, len(parts))
                out.append({"w": w, "s": round(at / 1000, 2)})
    out.sort(key=lambda w: w["s"])
    for n, w in enumerate(out):
        nxt = out[n + 1]["s"] if n + 1 < len(out) else w["s"] + 0.4
        w["e"] = round(max(w["s"] + 0.08, min(nxt, w["s"] + 0.6)), 2)
    return out


def download(url, job_dir, height=720):
    """The whole video (used for shorter videos)."""
    job_dir = Path(job_dir)

    def fn(ydl):
        ydl.download([url])
        return _biggest(job_dir, "source")

    with _youtube_guard(url):
        try:
            return _try_clients(url, {"format": _video_format(height), "merge_output_format": "mp4",
                                      "outtmpl": str(job_dir / "source.%(ext)s")}, fn)
        except Exception as e:
            _raise_friendly(e)


def download_audio(url, job_dir, start=None, end=None):
    """Audio only, optionally just one stretch — a few MB even for a long video."""
    from yt_dlp.utils import download_range_func
    job_dir = Path(job_dir)
    opts = {"format": "ba[ext=m4a]/ba/worst", "outtmpl": str(job_dir / "audio_src.%(ext)s")}
    if start is not None or end is not None:
        opts["download_ranges"] = download_range_func(None, [(max(0.0, start or 0.0), end or 99999999.0)])

    def fn(ydl):
        ydl.download([url])
        return _biggest(job_dir, "audio_src")

    with _youtube_guard(url):
        try:
            return _try_clients(url, opts, fn)
        except Exception as e:
            _raise_friendly(e)


def download_section(url, out_dir, stem, start, end, height=720):
    """Just one stretch of the video, for long sources."""
    from yt_dlp.utils import download_range_func
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    def fn(ydl):
        ydl.download([url])
        return _biggest(out_dir, stem)

    with _youtube_guard(url):
        try:
            return _try_clients(url, {"format": _video_format(height), "merge_output_format": "mp4",
                                      "outtmpl": str(out_dir / (stem + ".%(ext)s")),
                                      "download_ranges": download_range_func(None, [(max(0.0, start), end)])}, fn)
        except Exception as e:
            _raise_friendly(e)


def probe(path):
    out = run(["ffprobe", "-v", "error", "-print_format", "json",
               "-show_format", "-show_streams", str(path)])
    data = json.loads(out)
    v = next((s for s in data["streams"] if s["codec_type"] == "video"), None)
    if not v:
        raise RuntimeError("This file has no video track.")
    if not any(s["codec_type"] == "audio" for s in data["streams"]):
        raise RuntimeError("This file has no audio track, so there is nothing to transcribe.")
    w, h = int(v["width"]), int(v["height"])
    if w * h > 3840 * 2160 or w < 16 or h < 16:
        raise RuntimeError("This video's resolution isn't supported (4K is the largest).")
    rot = str((v.get("side_data_list") or [{}])[0].get("rotation", "0"))
    if rot.lstrip("-") in ("90", "270"):
        w, h = h, w
    return {"width": w, "height": h, "duration": float(data["format"]["duration"])}


def extract_audio(src, wav):
    run(["ffmpeg", "-y", "-v", "error", "-i", str(src), "-vn", "-ac", "1", "-ar", "16000",
         "-t", str(int(config.MAX_VIDEO_HOURS * 3600) + 60),
         "-af", "aresample=async=1:first_pts=0", "-c:a", "pcm_s16le", str(wav)])


def loudness_per_second(wav_path):
    """RMS level in dB for each second, from a 16kHz mono wav."""
    import numpy as np
    import soundfile as sf
    data, sr = sf.read(str(wav_path), dtype="int16")
    assert sr == 16000
    n = len(data) // 16000
    if n == 0:
        return [0.0]
    x = data[: n * 16000].reshape(n, 16000).astype("float32") / 32768.0
    rms = np.sqrt((x ** 2).mean(axis=1) + 1e-10)
    return (20 * np.log10(rms)).tolist()
