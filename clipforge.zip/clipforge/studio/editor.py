"""Editor operations: trim a clip, change its caption style or text,
and re-render it. All edits go through the same render path as the
original clip, so an edited clip looks identical in quality.
"""
from pathlib import Path

from . import db, render
from .media import probe


def edit_clip(clip_id, start=None, end=None, caption_style=None, caption_text=None,
              title=None, hook=None):
    """Re-render clip `clip_id` with the requested changes. Returns the
    updated clip record. Raises ValueError with a plain message on bad input."""
    clip = db.get_clip(clip_id)
    if not clip:
        raise ValueError("That clip doesn't exist any more.")
    job = db.get_job(clip["job_id"])
    if not job:
        raise ValueError("That clip's job is gone, so it can't be re-rendered.")
    new_start = float(start) if start is not None else clip["start"]
    new_end = float(end) if end is not None else clip["end"]
    if new_end - new_start < 3:
        raise ValueError("A clip has to be at least 3 seconds long — widen the trim.")
    if new_start < 0 or new_end > (job["duration"] or 0) + 1:
        raise ValueError("That trim is outside the video. Check the start and end times.")
    style = caption_style or clip["style"]
    if style not in ("bold", "karaoke", "minimal"):
        raise ValueError("Caption style has to be bold, karaoke or minimal.")
    words = clip["words"]
    if caption_text is not None:
        # replace the caption words inside the new window with the user's
        # text, spread evenly across it (timings are the editor's, not the
        # transcript's, and the record says so)
        text_words = caption_text.split()
        if not text_words:
            raise ValueError("Caption text can't be empty.")
        span = new_end - new_start
        words = [{"w": w, "s": round(new_start + span * i / len(text_words), 2),
                  "e": round(new_start + span * (i + 1) / len(text_words), 2)}
                 for i, w in enumerate(text_words)]
    job_dir = Path(config_data_dir()) / "jobs" / job["id"]
    source = _find_source(job_dir)
    if source is None:
        raise ValueError("The original video for this job is gone, so the clip can't be re-rendered.")
    clip_rec = {"start": new_start, "end": new_end, "hook": hook if hook is not None else clip["hook"],
                "style": style, "layout": clip["layout"]}
    out_dir = job_dir / "clips"
    name = f"clip-{clip_id}"
    result = render.render_clip(source, out_dir, name, clip_rec, words)
    db.update_clip(clip_id, start=new_start, end=new_end, style=style,
                   hook=clip_rec["hook"], title=title or clip["title"],
                   file=result["file"], cover=result["cover"],
                   words=words if caption_text is not None else
                   [dict(w, s=max(w["s"], new_start), e=min(w["e"], new_end))
                    for w in clip["words"] if new_start - 0.05 <= w["s"] < new_end])
    return db.get_clip(clip_id)


def config_data_dir():
    from . import config
    return config.DATA_DIR


def _find_source(job_dir):
    for name in ("source.mp4", "source.webm", "source.mkv", "source.mov"):
        p = Path(job_dir) / name
        if p.is_file():
            return p
    cands = sorted(Path(job_dir).glob("source.*"))
    return cands[0] if cands else None
