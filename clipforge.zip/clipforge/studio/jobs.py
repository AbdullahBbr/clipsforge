"""Job pipeline: fetch -> transcribe -> score -> render -> thumbnails.
Runs in a background thread so the web page stays responsive.
"""
import threading
import time
import uuid
from pathlib import Path

from . import config, db, media, render, score, thumbs, transcribe

_worker_lock = threading.Lock()


def job_dir(job_id):
    return config.DATA_DIR / "jobs" / job_id


def create_job(source, kind, max_clips=3, clip_length=45, lang="en", title=""):
    job_id = uuid.uuid4().hex[:12]
    job = {"id": job_id, "title": title or "", "source": source, "kind": kind,
           "status": "queued", "created_at": time.time(), "duration": 0,
           "max_clips": int(max_clips), "clip_length": float(clip_length), "lang": lang or "en"}
    db.create_job(job)
    (job_dir(job_id) / "clips").mkdir(parents=True, exist_ok=True)
    t = threading.Thread(target=_run_job, args=(job_id,), daemon=True)
    t.start()
    return job


def _set(job_id, **kw):
    db.update_job(job_id, **kw)


def resume_stuck_jobs():
    """Jobs left in a working state when a process died (e.g. an MCP
    client that started a job and then disconnected). The web server
    picks them up on startup: their old partial clips are dropped and
    the job runs again from the fetch step."""
    import sqlite3
    stuck = [j for j in db.list_jobs(limit=100)
             if j["status"] in ("queued", "downloading", "transcribing", "scoring", "rendering")]
    for job in stuck:
        with db._lock, db._connect() as conn:
            conn.execute("DELETE FROM clips WHERE job_id=?", (job["id"],))
        t = threading.Thread(target=_run_job, args=(job["id"],), daemon=True)
        t.start()
    return len(stuck)


def _run_job(job_id):
    job = db.get_job(job_id)
    if not job:
        return
    jdir = job_dir(job_id)
    try:
        _set(job_id, status="downloading", progress=0.05)
        source_path, duration, title = _fetch(job, jdir)
        _set(job_id, status="downloading", progress=0.2, duration=duration,
             title=title or job["title"])
        _set(job_id, status="transcribing", progress=0.3)
        words = _transcribe(job, jdir, source_path)
        _set(job_id, status="scoring", progress=0.5)
        loudness = _loudness(jdir, source_path)
        picks = score.score_windows(words, duration, job["clip_length"], job["max_clips"], loudness)
        if not picks:
            raise ValueError("No speech was found to make clips from. Try a video with talking in it.")
        _set(job_id, status="rendering", progress=0.6)
        for i, pick in enumerate(picks):
            _render_one(job, jdir, source_path, words, pick, i)
            _set(job_id, progress=0.6 + 0.35 * (i + 1) / len(picks))
        _set(job_id, status="done", progress=1.0)
    except Exception as e:
        _set(job_id, status="failed", error=str(e)[:500])


def _fetch(job, jdir):
    """Return (source_path, duration, title). Short videos: download whole.
    Long videos (>15 min): audio only for scoring, then each clip's video
    is fetched as a section when it renders."""
    if job["kind"] == "file":
        src = Path(job["source"])
        if not src.is_file():
            raise ValueError("The uploaded file is gone. Upload it again.")
        info = media.probe(src)
        dest = jdir / ("source" + src.suffix.lower())
        if src.resolve() != dest.resolve():
            import shutil
            shutil.copyfile(src, dest)
        return dest, info["duration"], src.stem
    url = job["source"]
    if not media.site_allowed(url):
        raise ValueError("That link isn't from a supported video site. Use a YouTube or Twitch link, a direct mp4 link, or upload the file.")
    meta = media.info(url)
    if meta["kind"] != "video" or not meta["title"]:
        raise ValueError("That link is a channel or playlist, not a single video.")
    duration = meta["duration"]
    if duration and duration <= 900:
        path = media.download(url, jdir, height=720)
        info = media.probe(path)
        return path, info["duration"], meta["title"]
    # long video: audio first, sections later
    audio = media.download_audio(url, jdir)
    wav = jdir / "audio.wav"
    media.extract_audio(audio, wav)
    return wav, duration, meta["title"]


def _transcribe(job, jdir, source_path):
    words = None
    if job["kind"] == "url":
        words = media.youtube_words(job["source"])
    if words:
        return words
    wav = jdir / "audio.wav"
    if source_path.suffix.lower() in (".wav",):
        wav = source_path
    elif not wav.is_file():
        media.extract_audio(source_path, wav)
    try:
        return transcribe.transcribe_words(wav, job["lang"])
    except Exception as e:
        raise RuntimeError(f"Transcription failed: {e}. The video may have no clear speech, or the speech model couldn't be downloaded.") from e


def _loudness(jdir, source_path):
    wav = jdir / "audio.wav"
    try:
        if not wav.is_file():
            media.extract_audio(source_path, wav)
        return media.loudness_per_second(wav)
    except Exception:
        return None


def _render_one(job, jdir, source_path, words, pick, index):
    clip_id = uuid.uuid4().hex[:12]
    title = score.title_from_hook(pick["hook"], f"Clip {index + 1}")
    clip_rec = {"start": pick["start"], "end": pick["end"], "hook": pick["hook"],
                "style": "bold", "layout": "crop"}
    out_dir = jdir / "clips"
    name = f"clip-{clip_id}"
    if job["kind"] == "url" and job["duration"] and job["duration"] > 900:
        # long source: fetch just this clip's video section. The section
        # starts at section_start (a keyframe may land a little earlier,
        # so captions can be off by a second on long videos — noted in README).
        section_start = max(0.0, pick["start"] - 2)
        section = media.download_section(job["source"], jdir / "sections", name,
                                         section_start, pick["end"] + 2)
        local = {"start": pick["start"] - section_start,
                 "end": pick["end"] - section_start,
                 "hook": pick["hook"], "style": "bold", "layout": "crop"}
        local_words = [{"w": w["w"], "s": w["s"] - section_start,
                        "e": w["e"] - section_start} for w in words
                       if pick["start"] <= w["s"] < pick["end"]]
        result = render.render_clip(section, out_dir, name, local, local_words)
        words_for_db = [w for w in words if pick["start"] <= w["s"] < pick["end"]]
    else:
        result = render.render_clip(source_path, out_dir, name, clip_rec, words)
        words_for_db = [w for w in words if pick["start"] <= w["s"] < pick["end"]]
    clip = {"id": clip_id, "job_id": job["id"], "title": title, "hook": pick["hook"],
            "start": pick["start"], "end": pick["end"], "score": pick["score"],
            "style": "bold", "layout": "crop", "file": result["file"],
            "cover": result["cover"], "words": words_for_db, "created_at": time.time()}
    db.create_clip(clip)
    # thumbnail, 1280x720
    try:
        thumbs.make_thumbnail(out_dir / result["file"], out_dir / f"{name}-thumb.jpg", title)
        db.update_clip(clip_id, file=result["file"])
    except Exception:
        pass
    return clip
