"""ClipForge — own-code rebuild of an OpusClip-style long-video-to-clips app.
Single-user, local only. No accounts, no billing, no OpusClip code or assets.
"""
