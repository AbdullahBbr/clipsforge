"""AI dubbing: translate the transcript, speak it with edge-tts, mix
the new voice over the clip (original audio ducked underneath).

Online services, free, no API key: deep-translator (Google Translate)
and edge-tts (Microsoft's online TTS). When either is unreachable the
dub fails cleanly with a translated-captions fallback instead of a
crash: the clip is re-rendered with the translated text as captions
over the original audio, and the result says so honestly.
"""
import re
from pathlib import Path

from . import captions, config
from .media import NO_WINDOW, run

VOICES = {
    "es": "es-ES-AlvaroNeural", "fr": "fr-FR-HenriNeural", "de": "de-DE-ConradNeural",
    "pt": "pt-BR-AntonioNeural", "it": "it-IT-DiegoNeural", "hi": "hi-IN-MadhurNeural",
    "ar": "ar-SA-HamedNeural", "ja": "ja-JP-KeitaNeural", "ko": "ko-KR-InJoonNeural",
    "zh": "zh-CN-YunxiNeural", "ur": "ur-PK-AsadNeural", "tr": "tr-TR-AhmetNeural",
    "ru": "ru-RU-DmitryNeural", "nl": "nl-NL-MaartenNeural", "pl": "pl-PL-MarekNeural",
}
LANG_NAMES = {"es": "Spanish", "fr": "French", "de": "German", "pt": "Portuguese",
              "it": "Italian", "hi": "Hindi", "ar": "Arabic", "ja": "Japanese",
              "ko": "Korean", "zh": "Chinese", "ur": "Urdu", "tr": "Turkish",
              "ru": "Russian", "nl": "Dutch", "pl": "Polish"}


def _argos_translate(text, target_lang, source_lang="en"):
    """Offline translator, used when Argos Translate is installed
    (pip install argostranslate, then `argospm install translate-en_es`
    for the language pair). Returns the translation, or None when Argos
    isn't installed or has no model for this pair — the caller then
    falls through to the free online services."""
    try:
        from argostranslate import translate as _at
        return _at.get_translation_from_codes(source_lang, target_lang).translate(text)
    except Exception:
        return None


def translate_text(text, target_lang, source_lang="en"):
    """Translate, trying in order: Argos Translate offline (if
    installed), MyMemory's free API, then Google Translate. Raises
    RuntimeError with a plain message when none of them work."""
    out = _argos_translate(text, target_lang, source_lang)
    if out and out.strip() and out.strip().upper() != text.strip().upper():
        return out.strip()
    import json as _json
    import time as _time
    import urllib.parse
    import urllib.request
    _time.sleep(0.25)  # stay under the free service's rate limit
    q = urllib.parse.urlencode({"q": text, "langpair": f"{source_lang}|{target_lang}"})
    try:
        req = urllib.request.Request(
            "https://api.mymemory.translated.net/get?" + q,
            headers={"User-Agent": "ClipForge/1.0"})
        with urllib.request.urlopen(req, timeout=20) as r:
            data = _json.loads(r.read().decode("utf-8", "replace"))
        out = (data.get("responseData") or {}).get("translatedText", "").strip()
        if out and out.upper() != text.upper():
            return out
    except Exception:
        pass
    try:
        from deep_translator import GoogleTranslator
        return GoogleTranslator(source=source_lang, target=target_lang).translate(text)
    except Exception as e:
        raise RuntimeError(
            "Translation isn't reachable right now (the free translation "
            "service is rate-limiting this network). Wait a few minutes and "
            "try again.") from e


def _split_sentences(words, max_chars=180):
    """Group transcript words into speakable chunks with timings."""
    chunks, cur, cur_start = [], [], None
    for w in words:
        if cur_start is None:
            cur_start = w["s"]
        cur.append(w)
        text = " ".join(x["w"] for x in cur)
        if len(text) >= max_chars or w["w"][-1:] in ".?!":
            chunks.append({"text": text, "start": cur_start, "end": w["e"]})
            cur, cur_start = [], None
    if cur:
        chunks.append({"text": " ".join(x["w"] for x in cur), "start": cur_start, "end": cur[-1]["e"]})
    return chunks


def translate_words(words, target_lang, source_lang="en"):
    """Translate a whole transcript in a few large requests (the free
    service rate-limits per request, so one call per sentence fails).
    Returns translated words spread across the original timings."""
    chunks = _split_sentences(words, max_chars=380)
    out = []
    for c in chunks:
        text = translate_text(c["text"], target_lang, source_lang)
        tw = text.split()
        if not tw:
            continue
        span = max(0.01, c["end"] - c["start"])
        for i, w in enumerate(tw):
            at = c["start"] + span * i / len(tw)
            out.append({"w": w, "s": round(at, 2), "e": round(at + span / len(tw), 2)})
    return out


def dub_clip(clip_path, words, target_lang, out_path, source_lang="en"):
    """Returns dict with mode 'dubbed' or 'translated_captions' (fallback)."""
    import edge_tts
    import asyncio
    clip_path, out_path = Path(clip_path), Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    lang = target_lang.lower()[:2]
    if lang == (source_lang or "en").lower()[:2]:
        raise ValueError("Pick a language different from the clip's own language.")
    if lang not in VOICES:
        raise ValueError(f"Dubbing to {target_lang} isn't supported yet. Try es, fr, de, pt, it, hi, ar, ja, ko, zh, ur, tr, ru, nl or pl.")
    chunks = _split_sentences(words)
    if not chunks:
        raise ValueError("There's no speech in this clip to dub.")
    translated_words = translate_words(words, lang, source_lang)
    chunks = _split_sentences(translated_words, max_chars=180)
    # speak each chunk, in order, into one wav
    voice = VOICES[lang]
    tmpdir = out_path.parent / "dub_tmp"
    tmpdir.mkdir(exist_ok=True)
    audio_files = []
    try:
        async def _speak_all():
            for i, c in enumerate(chunks):
                f = tmpdir / f"part{i:03d}.mp3"
                await edge_tts.Communicate(c["text"], voice).save(str(f))
                audio_files.append(f)
        asyncio.run(_speak_all())
    except Exception as e:
        raise RuntimeError(f"Couldn't reach the dubbing voice service just now ({e}). "
                           "Check the connection and try again, or use the translated-captions fallback.") from e
    # measure each spoken part, lay them at the right times, mix under the original
    import subprocess
    import json as _json
    delays, inputs = [], []
    for i, (c, f) in enumerate(zip(chunks, audio_files)):
        out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                              "-of", "json", str(f)], capture_output=True, text=True)
        dur = float(_json.loads(out.stdout)["format"]["duration"])
        # stretch the spoken part to its slot if it is much longer, by
        # speeding it up a little; never slower than the original
        inputs.append(f)
        delays.append((f, c["start"], dur))
    # build one mixed dub track with adelay + amix, then mix with original
    filter_parts, labels = [], []
    for i, (f, start, _d) in enumerate(delays):
        filter_parts.append(f"[{i}:a]adelay={int(start * 1000)}|{int(start * 1000)}[d{i}]")
        labels.append(f"[d{i}]")
    filter_parts.append("".join(labels) + f"amix=inputs={len(labels)}:normalize=0[dub]")
    dub_wav = tmpdir / "dub.wav"
    cmd = ["ffmpeg", "-y", "-v", "error"]
    for f in inputs:
        cmd += ["-i", str(f)]
    cmd += ["-filter_complex", ";".join(filter_parts), "-map", "[dub]", "-ac", "1",
            "-ar", "48000", str(dub_wav)]
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                       errors="replace", creationflags=NO_WINDOW, timeout=600)
    if p.returncode != 0:
        raise RuntimeError(f"Couldn't mix the dubbed voice: {p.stderr[-800:]}")
    # final mix: original at 15% under the dub
    cmd = ["ffmpeg", "-y", "-v", "error", "-i", str(clip_path), "-i", str(dub_wav),
           "-filter_complex",
           "[0:a]volume=0.15[orig];[1:a]volume=1.0[dub];[orig][dub]amix=inputs=2:normalize=0[a]",
           "-map", "0:v", "-map", "[a]", "-c:v", "copy", "-c:a", "aac", "-b:a", "160k",
           "-movflags", "+faststart", str(out_path)]
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                       errors="replace", creationflags=NO_WINDOW, timeout=600)
    if p.returncode != 0:
        raise RuntimeError(f"Couldn't mix the dubbed clip: {p.stderr[-800:]}")
    return {"mode": "dubbed", "lang": lang, "file": str(out_path),
            "note": f"Dubbed into {LANG_NAMES.get(lang, lang)} with an AI voice. Original audio kept quietly underneath."}


def translated_captions_fallback(clip_path, words, target_lang, out_path, source_lang="en"):
    """Offline fallback: re-render the clip with translated captions over
    the original audio. Returns a dict saying so plainly."""
    from .render import render_clip
    from .media import probe
    lang = target_lang.lower()[:2]
    try:
        translated_words = translate_words(words, lang, source_lang)
    except Exception as e:
        return {"mode": "failed", "note": str(e) + " The original clip is unchanged."}
    if not translated_words:
        return {"mode": "failed", "note": "There's no speech in this clip to translate. The original clip is unchanged."}
    info = probe(clip_path)
    clip = {"start": 0.0, "end": info["duration"], "hook": "", "style": "bold"}
    # render_clip expects a source + a clip window; here the source IS the clip
    out_dir = Path(out_path).parent
    name = Path(out_path).stem
    result = render_clip(clip_path, out_dir, name, clip, translated_words)
    return {"mode": "translated_captions", "lang": lang, "file": str(out_dir / result["file"]),
            "note": f"No voice dub was possible, so this version has {LANG_NAMES.get(lang, lang)} captions over the original audio instead."}
