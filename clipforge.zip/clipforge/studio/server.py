"""ClipForge web app: FastAPI + plain HTML frontend in web/.

Every error is a plain-language message, never a bare 500.
Run: python -m studio.server  ->  http://127.0.0.1:8765
"""
import shutil
import time
import uuid
from pathlib import Path

from fastapi import FastAPI, File, Form, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from . import config, db, dub, editor, jobs, media, render, schedule, thumbs

app = FastAPI(title="ClipForge")
WEB = Path(__file__).resolve().parent.parent / "web"


async def _body(request):
    """POST body as a dict; an empty body is fine ({}), not a crash."""
    try:
        return await request.json() or {}
    except Exception:
        return {}

@app.on_event("startup")
def _startup():
    db.init()
    jobs.resume_stuck_jobs()


@app.exception_handler(Exception)
async def _plain_error(request: Request, exc: Exception):
    return JSONResponse({"error": str(exc)[:500] or "Something went wrong. Try again."},
                        status_code=400)


def _job_view(job):
    clips = db.clips_for_job(job["id"]) if job else []
    return {**job, "clips": [{k: c[k] for k in
                              ("id", "title", "hook", "start", "end", "score", "style",
                               "file", "cover") if k in c} for c in clips]}


@app.get("/api/health")
def health():
    return {"ok": True, "app": "ClipForge"}


@app.post("/api/jobs")
async def create_job(url: str = Form(""), max_clips: int = Form(3),
                     clip_length: float = Form(45), lang: str = Form("en")):
    url = (url or "").strip()
    if not url:
        return JSONResponse({"error": "Paste a YouTube or Twitch link first."}, status_code=400)
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    if not media.site_allowed(url):
        return JSONResponse({"error": "That link isn't from a supported video site. Use a YouTube or Twitch link, a direct mp4 link, or upload the file."},
                            status_code=400)
    try:
        meta = media.info(url)
    except Exception as e:
        return JSONResponse({"error": str(e)[:400]}, status_code=400)
    job = jobs.create_job(url, "url", max_clips=max_clips, clip_length=clip_length,
                          lang=lang, title=meta.get("title", ""))
    return _job_view(db.get_job(job["id"]))


@app.post("/api/upload")
async def upload(file: UploadFile = File(...), max_clips: int = Form(3),
                 clip_length: float = Form(45), lang: str = Form("en")):
    name = Path(file.filename or "video").name
    if Path(name).suffix.lower() not in (".mp4", ".mov", ".mkv", ".webm", ".m4v"):
        return JSONResponse({"error": "That file isn't a video ClipForge can open. Use an mp4, mov, mkv or webm file."},
                            status_code=400)
    tmp = config.DATA_DIR / "uploads"
    tmp.mkdir(parents=True, exist_ok=True)
    dest = tmp / f"{uuid.uuid4().hex[:8]}-{name}"
    with dest.open("wb") as f:
        shutil.copyfileobj(file.file, f)
    try:
        media.probe(dest)
    except Exception as e:
        dest.unlink(missing_ok=True)
        return JSONResponse({"error": str(e)[:400]}, status_code=400)
    job = jobs.create_job(str(dest), "file", max_clips=max_clips,
                          clip_length=clip_length, lang=lang, title=Path(name).stem)
    return _job_view(db.get_job(job["id"]))


@app.get("/api/jobs")
def list_jobs():
    return [_job_view(j) for j in db.list_jobs()]


@app.get("/api/jobs/{job_id}")
def get_job(job_id: str):
    job = db.get_job(job_id)
    if not job:
        return JSONResponse({"error": "That job doesn't exist."}, status_code=404)
    return _job_view(job)


@app.get("/api/clips")
def list_clips():
    out = []
    for c in db.list_clips():
        job = db.get_job(c["job_id"])
        out.append({**{k: c[k] for k in ("id", "job_id", "title", "hook", "start", "end",
                                        "score", "style", "file", "cover")},
                    "job_title": job["title"] if job else ""})
    return out


@app.get("/api/clips/{clip_id}")
def get_clip(clip_id: str):
    clip = db.get_clip(clip_id)
    if not clip:
        return JSONResponse({"error": "That clip doesn't exist."}, status_code=404)
    return clip


@app.get("/api/clips/{clip_id}/video")
def clip_video(clip_id: str):
    clip = db.get_clip(clip_id)
    if not clip:
        return JSONResponse({"error": "That clip doesn't exist."}, status_code=404)
    path = jobs.job_dir(clip["job_id"]) / "clips" / clip["file"]
    if not path.is_file():
        return JSONResponse({"error": "That clip's video file is gone."}, status_code=404)
    return FileResponse(path, media_type="video/mp4", filename=clip["file"])


@app.get("/api/clips/{clip_id}/thumbnail")
def clip_thumb(clip_id: str):
    clip = db.get_clip(clip_id)
    if not clip:
        return JSONResponse({"error": "That clip doesn't exist."}, status_code=404)
    thumb = jobs.job_dir(clip["job_id"]) / "clips" / f"clip-{clip_id}-thumb.jpg"
    if thumb.is_file():
        return FileResponse(thumb, media_type="image/jpeg")
    cover = jobs.job_dir(clip["job_id"]) / "clips" / clip["cover"]
    if cover.is_file():
        return FileResponse(cover, media_type="image/jpeg")
    return JSONResponse({"error": "No thumbnail for this clip yet."}, status_code=404)


@app.post("/api/clips/{clip_id}/edit")
async def edit_clip(clip_id: str, request: Request):
    body = await _body(request)
    try:
        clip = editor.edit_clip(clip_id, start=body.get("start"), end=body.get("end"),
                                caption_style=body.get("caption_style"),
                                caption_text=body.get("caption_text"),
                                title=body.get("title"), hook=body.get("hook"))
    except Exception as e:
        return JSONResponse({"error": str(e)[:400]}, status_code=400)
    return clip


@app.post("/api/clips/{clip_id}/dub")
async def dub_clip(clip_id: str, request: Request):
    body = await _body(request)
    target = (body.get("target_lang") or "").strip()
    if not target:
        return JSONResponse({"error": "Pick a language to dub into, for example 'es' for Spanish."},
                            status_code=400)
    clip = db.get_clip(clip_id)
    if not clip:
        return JSONResponse({"error": "That clip doesn't exist."}, status_code=404)
    clip_path = jobs.job_dir(clip["job_id"]) / "clips" / clip["file"]
    out = jobs.job_dir(clip["job_id"]) / "clips" / f"clip-{clip_id}-dub-{target[:2]}.mp4"
    try:
        result = dub.dub_clip(clip_path, clip["words"], target, out)
    except Exception as e:
        # clean fallback: translated captions over the original audio
        try:
            result = dub.translated_captions_fallback(clip_path, clip["words"], target, out)
        except Exception:
            return JSONResponse({"error": str(e)[:400]}, status_code=400)
        if result.get("mode") == "failed":
            return JSONResponse({"error": result["note"]}, status_code=400)
    return result


@app.post("/api/clips/{clip_id}/thumbnail")
async def make_thumb(clip_id: str, request: Request):
    body = await _body(request)
    clip = db.get_clip(clip_id)
    if not clip:
        return JSONResponse({"error": "That clip doesn't exist."}, status_code=404)
    clip_path = jobs.job_dir(clip["job_id"]) / "clips" / clip["file"]
    out = jobs.job_dir(clip["job_id"]) / "clips" / f"clip-{clip_id}-thumb.jpg"
    try:
        thumbs.make_thumbnail(clip_path, out, body.get("title") or clip["title"])
    except Exception as e:
        return JSONResponse({"error": str(e)[:400]}, status_code=400)
    return {"thumbnail": f"/api/clips/{clip_id}/thumbnail"}


@app.post("/api/clips/{clip_id}/reframe")
async def reframe(clip_id: str, request: Request):
    body = await _body(request)
    ratio = body.get("ratio", "9:16")
    clip = db.get_clip(clip_id)
    if not clip:
        return JSONResponse({"error": "That clip doesn't exist."}, status_code=404)
    src = jobs.job_dir(clip["job_id"]) / "clips" / clip["file"]
    out = jobs.job_dir(clip["job_id"]) / "clips" / f"clip-{clip_id}-{ratio.replace(':', 'x')}.mp4"
    try:
        render.reframe_clip(src, out, ratio)
    except Exception as e:
        return JSONResponse({"error": str(e)[:400]}, status_code=400)
    return {"file": out.name, "ratio": ratio}


@app.get("/api/schedule")
def list_schedule():
    return db.list_schedules()


@app.post("/api/schedule")
async def create_schedule(request: Request):
    body = await _body(request)
    try:
        entry = schedule.queue_post(body.get("clip_id", ""), body.get("platform", ""),
                                    body.get("publish_at", ""), body.get("title", ""),
                                    body.get("description", ""), body.get("hashtags", ""))
    except Exception as e:
        return JSONResponse({"error": str(e)[:400]}, status_code=400)
    return entry


@app.post("/api/schedule/{schedule_id}/publish")
def publish_schedule(schedule_id: str):
    try:
        return schedule.try_publish(schedule_id)
    except Exception as e:
        return JSONResponse({"error": str(e)[:400]}, status_code=400)


app.mount("/", StaticFiles(directory=str(WEB), html=True), name="web")


def main():
    import uvicorn
    uvicorn.run("studio.server:app", host="127.0.0.1", port=config.PORT, log_level="info")


if __name__ == "__main__":
    main()
