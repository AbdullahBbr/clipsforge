"""Local speech-to-text with faster-whisper (word timings for captions).

The model (tiny/base) is downloaded once from Hugging Face on first use
and cached. No API key, nothing leaves the machine.
"""
import threading

_lock = threading.Lock()
_model = None
_model_name = None


def _get_model():
    global _model, _model_name
    from faster_whisper import WhisperModel
    from . import config
    with _lock:
        if _model is None or _model_name != config.WHISPER_MODEL:
            _model = WhisperModel(config.WHISPER_MODEL, device="cpu", compute_type="int8")
            _model_name = config.WHISPER_MODEL
        return _model


def transcribe_words(wav_path, lang="en"):
    """[{'w': word, 's': start_sec, 'e': end_sec}, ...] for a wav file."""
    model = _get_model()
    segments, _info = model.transcribe(str(wav_path), language=lang or None,
                                       word_timestamps=True, vad_filter=True)
    words = []
    for seg in segments:
        for w in (seg.words or []):
            text = w.word.strip()
            if text:
                words.append({"w": text, "s": round(float(w.start), 2), "e": round(float(w.end), 2)})
    words.sort(key=lambda w: w["s"])
    for i, w in enumerate(words):
        nxt = words[i + 1]["s"] if i + 1 < len(words) else w["e"] + 0.4
        w["e"] = round(max(w["s"] + 0.08, min(nxt, w["s"] + 0.6)), 2)
    return words


def transcribe_text(wav_path, lang="en"):
    """Plain transcript text (used for dubbing source text)."""
    model = _get_model()
    segments, _info = model.transcribe(str(wav_path), language=lang or None, vad_filter=True)
    return " ".join(seg.text.strip() for seg in segments).strip()
