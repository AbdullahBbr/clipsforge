"""Smoke tests: no video needed. Run: python -m pytest tests/ -x -q"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from studio import captions, score, thumbs  # noqa: E402


def test_ass_templates():
    words = [{"w": "never", "s": 0.0, "e": 0.4}, {"w": "gonna", "s": 0.4, "e": 0.8},
             {"w": "give", "s": 0.8, "e": 1.1}, {"w": "you", "s": 1.1, "e": 1.4},
             {"w": "up", "s": 1.4, "e": 1.8}]
    for style in ("bold", "karaoke", "minimal"):
        ass = captions.build_ass(words, 0, 2, "Never gonna give you up", style)
        assert "PlayResX: 1080" in ass and "PlayResY: 1920" in ass
        assert "Dialogue:" in ass and "never" in ass.lower()


def test_scoring_finds_a_clip():
    words = []
    t = 0.0
    for i in range(200):
        words.append({"w": "how" if i % 37 == 0 else "word", "s": t, "e": t + 0.3})
        t += 0.45
    picks = score.score_windows(words, 90, clip_length=30, max_clips=2)
    assert len(picks) == 2
    assert all(p["end"] - p["start"] >= 15 for p in picks)
    assert picks[0]["score"] >= picks[1]["score"]


def test_scoring_empty_is_empty():
    assert score.score_windows([], 60) == []


def test_thumbnail_from_video(tmp_path):
    # a 2-second black test video, made with ffmpeg
    import subprocess
    src = tmp_path / "test.mp4"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i",
                    "color=c=black:s=640x360:d=2", "-f", "lavfi", "-i", "anullsrc",
                    "-shortest", str(src)], check=True)
    out = tmp_path / "thumb.jpg"
    thumbs.make_thumbnail(src, out, "Test Title Here")
    from PIL import Image
    img = Image.open(out)
    assert img.size == (1280, 720)


if __name__ == "__main__":
    test_ass_templates()
    test_scoring_finds_a_clip()
    test_scoring_empty_is_empty()
    import tempfile
    with tempfile.TemporaryDirectory() as d:
        test_thumbnail_from_video(Path(d))
    print("smoke tests passed")
