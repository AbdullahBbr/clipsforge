const $ = (id) => document.getElementById(id);
const msg = (el, t) => { el.textContent = t; };
async function api(path, opts) {
  const r = await fetch(path, opts);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}
async function refresh() {
  const jobs = await api("/api/jobs");
  $("jobs").innerHTML = jobs.map((j) => `<div class="job"><b>${esc(j.title || j.id)}</b> — ${j.status} ${Math.round((j.progress || 0) * 100)}%${j.error ? ` — <span style="color:#f87171">${esc(j.error)}</span>` : ""}<br><small>${j.clips.length} clips · ${j.source}</small></div>`).join("") || "No jobs yet.";
  const clips = await api("/api/clips");
  $("clips").innerHTML = clips.map((c) => `
    <div class="clip">
      <img src="/api/clips/${c.id}/thumbnail" alt="thumbnail" onerror="this.style.display='none'">
      <video src="/api/clips/${c.id}/video" controls preload="none"></video>
      <b>${esc(c.title)}</b> <small>score ${c.score} · ${c.start}s–${c.end}s</small>
      <div>${esc(c.hook || "")}</div>
      <div class="row">
        <button onclick="editClip('${c.id}')">Edit</button>
        <button onclick="dubClip('${c.id}')">Dub to Spanish</button>
        <button onclick="thumbClip('${c.id}')">Thumbnail</button>
        <button onclick="copyId('${c.id}')">Copy id</button>
      </div>
      <small>id: ${c.id}</small>
    </div>`).join("") || "No clips yet — make a job first.";
  const sch = await api("/api/schedule");
  $("schedule").innerHTML = sch.map((s) => `<div class="job">${esc(s.platform)} · ${esc(s.publish_at)} · ${esc(s.title || s.clip_id)} — <b>${s.status}</b>${s.note ? ` — ${esc(s.note)}` : ""}</div>`).join("") || "Nothing scheduled.";
}
function esc(s) { return String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }
function copyId(id) { navigator.clipboard.writeText(id); $("sch-clip").value = id; }
let editing = null;
function editClip(id) {
  editing = id;
  fetch(`/api/clips/${id}`).then((r) => r.json()).then((c) => {
    $("ed-title").textContent = "Edit clip — " + (c.title || id);
    $("ed-start").value = c.start; $("ed-end").value = c.end;
    $("ed-style").value = c.style || "bold"; $("ed-text").value = "";
    $("editor").showModal();
  });
}
async function dubClip(id) {
  try { const r = await api(`/api/clips/${id}/dub`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ target_lang: "es" }) }); alert(r.mode + ": " + (r.note || "")); }
  catch (e) { alert(e.message); }
}
async function thumbClip(id) {
  try { await api(`/api/clips/${id}/thumbnail`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({}) }); refresh(); }
  catch (e) { alert(e.message); }
}
$("ed-save").onclick = async () => {
  try {
    await api(`/api/clips/${editing}/edit`, { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ start: parseFloat($("ed-start").value), end: parseFloat($("ed-end").value),
        caption_style: $("ed-style").value, caption_text: $("ed-text").value || null }) });
    msg($("ed-msg"), "Saved — re-rendered.");
    refresh();
  } catch (e) { msg($("ed-msg"), e.message); }
};
$("job-form").onsubmit = async (e) => {
  e.preventDefault();
  try {
    const fd = new FormData();
    fd.append("url", $("url").value); fd.append("max_clips", $("max-clips").value);
    fd.append("clip_length", $("clip-length").value); fd.append("lang", $("lang").value);
    const j = await api("/api/jobs", { method: "POST", body: fd });
    msg($("job-msg"), "Job started: " + (j.title || j.id));
    refresh();
  } catch (err) { msg($("job-msg"), err.message); }
};
$("upload-form").onsubmit = async (e) => {
  e.preventDefault();
  const f = $("file").files[0];
  if (!f) { msg($("job-msg"), "Choose a video file first."); return; }
  try {
    const fd = new FormData();
    fd.append("file", f); fd.append("max_clips", $("max-clips").value);
    fd.append("clip_length", $("clip-length").value); fd.append("lang", $("lang").value);
    const j = await api("/api/upload", { method: "POST", body: fd });
    msg($("job-msg"), "Upload started: " + (j.title || j.id));
    refresh();
  } catch (err) { msg($("job-msg"), err.message); }
};
$("schedule-form").onsubmit = async (e) => {
  e.preventDefault();
  try {
    await api("/api/schedule", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ clip_id: $("sch-clip").value, platform: $("sch-platform").value,
        publish_at: $("sch-when").value, title: $("sch-title").value }) });
    refresh();
  } catch (err) { alert(err.message); }
};
refresh();
setInterval(refresh, 8000);
